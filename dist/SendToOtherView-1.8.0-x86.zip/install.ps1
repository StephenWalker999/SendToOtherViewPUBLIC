[CmdletBinding()]
param(
    [ValidateSet('x64', 'x86')]
    [string] $Platform = 'x64',
    [string] $NotepadPlusPlusDir,
    [string] $ConfigDir = (Join-Path $env:APPDATA 'Notepad++'),
    [ValidateSet('Release', 'Debug')]
    [string] $Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$pluginName = 'SendToOtherView'
$root = $PSScriptRoot
$packagedDll = Join-Path $root "$pluginName.dll"
$buildDll = Join-Path $root "$Platform\$Configuration\$pluginName.dll"
$dll = if (Test-Path -LiteralPath $packagedDll) { $packagedDll } else { $buildDll }

if ([string]::IsNullOrWhiteSpace($NotepadPlusPlusDir)) {
    $programFilesDir = $env:ProgramFiles
    if ($Platform -eq 'x86' -and ${env:ProgramFiles(x86)}) {
        $programFilesDir = ${env:ProgramFiles(x86)}
    }
    $NotepadPlusPlusDir = Join-Path $programFilesDir 'Notepad++'
}
if (-not (Test-Path -LiteralPath $dll)) {
    throw "Plugin DLL not found beside install.ps1 or at $buildDll. Build SendToOtherView.sln first."
}

$pluginDir = Join-Path (Join-Path $NotepadPlusPlusDir 'plugins') $pluginName
New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null
Copy-Item -LiteralPath $dll -Destination (Join-Path $pluginDir "$pluginName.dll") -Force

$contextMenu = Join-Path $ConfigDir 'contextMenu.xml'
if (-not (Test-Path -LiteralPath $contextMenu)) {
    throw "contextMenu.xml not found at $contextMenu. In Notepad++, use Settings > Edit Popup ContextMenu once, then retry."
}

$xmlText = Get-Content -LiteralPath $contextMenu -Raw
$closingTag = '</ScintillaContextMenu>'
if (-not $xmlText.Contains($closingTag)) {
    throw "Could not find $closingTag in $contextMenu."
}
Copy-Item -LiteralPath $contextMenu -Destination "$contextMenu.SendToOtherView.bak" -Force
$xmlText = [regex]::Replace($xmlText, '(?m)^.*PluginEntryName="(?:Line|Send) to Other View".*(?:\r?\n)?', '')
$snippet = Get-Content -LiteralPath (Join-Path $root 'context-menu-snippet.xml') -Raw
$xmlText = $xmlText.Replace($closingTag, "$snippet`r`n$closingTag")
[void]([xml]$xmlText)
Set-Content -LiteralPath $contextMenu -Value $xmlText -Encoding utf8

Write-Host "Installed $pluginName. Fully exit and restart Notepad++ to load it and its context-menu entries."
